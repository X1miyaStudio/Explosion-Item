scoreboard players set #ei.thrown_only ei.cfg 1
tellraw @a [{"text":"[Explosion Item] ","color":"gold"},{"text":"Режим только брошенных предметов: взводятся лишь предметы от игроков (природный дроп и обломки безопасны).","color":"yellow"}]
