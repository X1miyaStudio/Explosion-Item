scoreboard players set #ei.thrown_only ei.cfg 0
tellraw @a [{"text":"[Explosion Item] ","color":"gold"},{"text":"Режим всего дропа включён (с защитой от бесконечной цепочки обломков).","color":"yellow"}]
