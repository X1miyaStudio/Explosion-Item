gamerule mob_griefing false
tellraw @a [{"text":"[Explosion Item] ","color":"gold"},{"text":"Безопасный режим включён: взрывы криперов не разрушают блоки.","color":"yellow"}]
