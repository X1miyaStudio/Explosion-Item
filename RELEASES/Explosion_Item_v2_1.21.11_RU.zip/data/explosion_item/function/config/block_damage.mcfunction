gamerule mob_griefing true
tellraw @a [{"text":"[Explosion Item] ","color":"gold"},{"text":"Разрушение блоков включено через mob_griefing true.","color":"red"}]
    
