scoreboard objectives remove ei.timer
scoreboard objectives remove ei.fx
scoreboard objectives remove ei.power
scoreboard objectives remove ei.count
tellraw @a [{"text":"[Explosion Item] ","color":"gold"},{"text":"Счётчики удалены. Отключи или удали датапак, чтобы остановить дальнейшую работу.","color":"yellow"}]
